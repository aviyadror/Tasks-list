localStorage.clear();
let toDoItem = document.querySelector('#todo-item');
;
let dellAll = document.querySelector('#todo-delall');
;
let dellComp = document.querySelector('#todo-delcom');
;
let todoList = document.querySelector('#todo-list');
;
let todoSave = document.querySelector('#todo-save');
;
let arrRemove = [];
let count = 0;
let arrTasks = [];
class Task {
    constructor(id, text) {
        this.id = id;
        this.text = text;
    }
}
todoSave.addEventListener("click", addTask);
function taskToHtml(val) {
    return `
        <div class='taskPost' id='task_${count}'>
            
            <span class="todoVal" id='span_${count}'>${val}</span><p class='btnDone' onclick='changeTask(${count++})'>&#10004</p><br><br><br>
            
        </div>`;
}
function changeTask(id) {
    console.log(document.querySelector(`#task_${id}`));
    document.querySelector(`#task_${id}`).classList.remove("taskPost");
    document.querySelector(`#task_${id}`).classList.add("doneStyle");
    arrRemove.push(id);
}
function addTask() {
    // localStorage.clear();
    let newTask = new Task(count, toDoItem.value);
    arrTasks.push(newTask);
    localStorage.setItem(count.toString(), JSON.stringify(newTask));
    console.log(newTask);
    console.log("arrTasks ", arrTasks);
    console.log(localStorage);
    // console.log(localStorage.getItem(JSON.parse(`${count}`)))
    // let stor = localStorage.getItem(JSON.parse(`${count}`))
    // console.log(JSON.parse(stor))
    // stor=Array.from(stor);
    // stor.forEach(el=>{(console.log(el))})
    todoList.innerHTML += taskToHtml(toDoItem.value);
}
function deleteAll() {
    localStorage.clear();
    if (confirm("Delete tasks?")) {
        todoList.innerHTML = "";
    }
    arrRemove = [];
    console.log(localStorage);
}
function deleteComp() {
    console.log("arrRemove", arrRemove);
    arrRemove.forEach((el) => {
        console.log(el);
        localStorage.removeItem(el);
    });
    console.log(localStorage);
    let doneArr = document.querySelectorAll(".doneStyle");
    doneArr.forEach(el => el.remove());
}
dellAll.addEventListener("click", deleteAll);
dellComp.addEventListener("click", deleteComp);

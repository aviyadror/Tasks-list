localStorage.clear();
let toDoItem:any =<HTMLInputElement>document.querySelector('#todo-item');
;
let dellAll:any = <HTMLInputElement>document.querySelector('#todo-delall');
;
let dellComp:any= <HTMLInputElement>document.querySelector('#todo-delcom');
;
let todoList:any = <HTMLInputElement>document.querySelector('#todo-list');
;
let todoSave = document.querySelector('#todo-save');
;
let arrRemove:Array<Task> = []

let count:number = 0;
let arrTasks:Array<Task> = []; 

class Task{
    public id;
    public text;
    

    constructor(id,text){
        this.id = id;
        this.text = text;
    }

}


todoSave.addEventListener("click",addTask)

function taskToHtml(val:string) {
    return `
        <div class='taskPost' id='task_${count}'>
            
            <span class="todoVal" id='span_${count}'>${val}</span><p class='btnDone' onclick='changeTask(${count++})'>&#10004</p><br><br><br>
            
        </div>`;
}

function changeTask(id:number):void {
    console.log(document.querySelector(`#task_${id}`));
    document.querySelector(`#task_${id}`).classList.remove("taskPost");
    
    document.querySelector(`#task_${id}`).classList.add("doneStyle");
    arrRemove.push(id)
    
}

function addTask():void {

    // localStorage.clear();
    let newTask = new Task(count,(<HTMLInputElement>toDoItem).value)
    arrTasks.push(newTask);
    localStorage.setItem(count.toString(),JSON.stringify(newTask));
    console.log(newTask)
    console.log("arrTasks ", arrTasks)
    console.log(localStorage)
    // console.log(localStorage.getItem(JSON.parse(`${count}`)))
    // let stor = localStorage.getItem(JSON.parse(`${count}`))
    // console.log(JSON.parse(stor))
    // stor=Array.from(stor);
    // stor.forEach(el=>{(console.log(el))})
    
    todoList.innerHTML += taskToHtml((<HTMLInputElement>toDoItem).value);

    
} 


function deleteAll():void{
    localStorage.clear();
    if(confirm("Delete tasks?")){
        todoList.innerHTML=""
    }
    arrRemove=[]
    console.log(localStorage);
}

function deleteComp():void{
    console.log("arrRemove", arrRemove)
    arrRemove.forEach((el)=>{
        console.log(el)
        localStorage.removeItem(el);
    })
    console.log(localStorage)
    let doneArr = document.querySelectorAll(".doneStyle")
    doneArr.forEach(el=> el.remove())

}
dellAll.addEventListener("click",deleteAll)
dellComp.addEventListener("click",deleteComp)